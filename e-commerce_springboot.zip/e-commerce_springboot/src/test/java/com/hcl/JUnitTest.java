package com.hcl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.isA;

import java.util.ArrayList;

import org.assertj.core.api.Assertions;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class JUnitTest {
     
    int totalNumberOfApplicants = 0;
    int totalNumberOfAcceptableApplicants = 10;
    ArrayList listOfValidStrings = new ArrayList();
     
    @BeforeEach()
    public void setData(){
        this.totalNumberOfApplicants = 9;
        listOfValidStrings.add("object_1");
        listOfValidStrings.add("object_2");
        listOfValidStrings.add("object_3");
    }
     
    @Test
    public void testAssertThatEqual() {
        assertThat("123",is("123"));
    }
     
    private void assertThat(String string, Matcher<String> matcher) {
		// TODO Auto-generated method stub
		
	}

	@Test
    public void testAssertThatNotEqual() {
        Assertions.assertThat(totalNumberOfApplicants);
    }
     
    @Test
    public void testAssertThatObject() {
        assertThat("123",isA(String.class));
    }
     
     
    @Test
    public void testAssertThatWMessage(){
        Assertions.assertThat("They are not equal!");
    }
}