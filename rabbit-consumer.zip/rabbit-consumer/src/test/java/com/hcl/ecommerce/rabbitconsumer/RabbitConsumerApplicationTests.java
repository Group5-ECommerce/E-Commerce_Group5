package com.hcl.ecommerce.rabbitconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RabbitConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
